import os
import hmac
import hashlib
import base64
import json
from pathlib import Path
from typing import List, Dict

from flask import Flask, request, abort, jsonify, render_template

# tomllib / tomli 互換
try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib

import requests

# --- Paths & data ---
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
CONV_FILE = DATA_DIR / "conversation.jsonl"
MEM_FILE = DATA_DIR / "memory.json"
TODO_FILE = DATA_DIR / "todos.json"
CFG_FILE = Path("config.toml")

def load_cfg() -> dict:
    with open(CFG_FILE, "rb") as f:
        return tomllib.load(f)

def load_json(p: Path, default):
    if not p.exists():
        return default
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def save_json(p: Path, obj):
    with open(p, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)

def append_jsonl(p: Path, obj):
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False) + "\n")

# Ensure files
if not MEM_FILE.exists():
    save_json(MEM_FILE, {"facts": [], "journals": []})
if not TODO_FILE.exists():
    save_json(TODO_FILE, [])
# conversation.jsonl is append-only

cfg = load_cfg()

# --- OpenAI (via requests) ---
def openai_chat(messages: List[Dict[str, str]]) -> str:
    base_url = cfg.get("openai", {}).get("base_url", "https://api.openai.com/v1")
    model = cfg.get("openai", {}).get("model", "gpt-4o-mini")
    temperature = cfg.get("openai", {}).get("temperature", 0.6)
    max_tokens = cfg.get("openai", {}).get("max_tokens", 800)

    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        return "（OPENAI_API_KEY が未設定です。RenderのEnvironmentに設定してください）"

    url = f"{base_url}/chat/completions"
    headers = {"Authorization": f"Bearer {api_key}"}
    payload = {"model": model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens}
    r = requests.post(url, headers=headers, json=payload, timeout=90)
    r.raise_for_status()
    data = r.json()
    return data["choices"][0]["message"]["content"].strip()

# --- Memory helpers ---
def build_memory_hint() -> str:
    mem = load_json(MEM_FILE, {"facts": [], "journals": []})
    parts = []
    if mem.get("facts"):
        parts.append("■覚えていること:\n- " + "\n- ".join(mem["facts"][-20:]))
    if mem.get("journals"):
        parts.append("■最近の出来事:\n- " + "\n- ".join(mem["journals"][-10:]))
    return "\n\n".join(parts) or "（まだ記憶はありません）"

def handle_command(cmd: str):
    cmd = cmd.strip()
    if cmd.startswith("/todo"):
        todos = load_json(TODO_FILE, [])
        rest = cmd.replace("/todo", "", 1).strip()
        if rest.startswith("追加"):
            item = rest.replace("追加", "", 1).strip()
            if item:
                todos.append({"title": item, "done": False})
                save_json(TODO_FILE, todos)
                return f"TODOを追加したよ：{item}"
            return "追加する内容を教えてね。例：/todo 追加 牛乳を買う"
        elif rest.startswith("一覧"):
            if not todos:
                return "TODOは空だよ。"
            lines = [f"{i+1}. [{'✓' if t['done'] else ' '}] {t['title']}" for i, t in enumerate(todos)]
            return "\n".join(lines)
        elif rest.startswith("完了"):
            idx_str = rest.replace("完了", "", 1).strip()
            if idx_str.isdigit():
                idx = int(idx_str) - 1
                todos = load_json(TODO_FILE, [])
                if 0 <= idx < len(todos):
                    todos[idx]["done"] = True
                    save_json(TODO_FILE, todos)
                    return f"完了にしたよ：{todos[idx]['title']}"
            return "正しい番号を指定してね。例：/todo 完了 2"
        else:
            return "使い方：/todo 追加 〇〇 | /todo 一覧 | /todo 完了 3"
    elif cmd.startswith("/覚えて"):
        text = cmd.replace("/覚えて", "", 1).strip()
        mem = load_json(MEM_FILE, {"facts": [], "journals": []})
        if text:
            mem["facts"].append(text)
            save_json(MEM_FILE, mem)
            return f"覚えたよ：{text}"
        return "覚える内容を入れてね。例：/覚えて 好きな飲み物は烏龍茶"
    elif cmd.startswith("/思い出して"):
        return "長期メモの要約だよ：\n" + build_memory_hint()
    return None

# --- Tina System Prompt ---
def tina_system_prompt():
    name = cfg.get("name", "ティナ")
    tone = cfg.get("tone", "friendly")
    style = "フレンドリーで親しみやすく、絵文字は控えめに、簡潔に答える。" if tone=="friendly" else "礼儀正しく丁寧で、簡潔に答える。"
    return {"role": "system",
            "content": f"あなたは生活を手助けする日本語アシスタント『{name}』です。{style} 事実に忠実で、安全第一で回答します。"}

# --- Flask ---
app = Flask(__name__)

@app.get("/")
def root():
    return render_template("index.html")

@app.post("/chat")
def chat_http():
    data = request.get_json(force=True)
    text = (data or {}).get("message", "").strip()
    if not text:
        return jsonify({"reply": "（メッセージが空だよ）"}), 400

    # command?
    cmd_resp = handle_command(text)
    if cmd_resp:
        append_jsonl(CONV_FILE, {"role": "user", "content": text})
        append_jsonl(CONV_FILE, {"role": "assistant", "content": cmd_resp})
        return jsonify({"reply": cmd_resp})

    msgs = [tina_system_prompt(), {"role": "system", "content": build_memory_hint()}, {"role": "user", "content": text}]
    try:
        reply = openai_chat(msgs)
    except Exception as e:
        reply = f"ごめん、エラーが出たかも…：{e}"

    append_jsonl(CONV_FILE, {"role": "user", "content": text})
    append_jsonl(CONV_FILE, {"role": "assistant", "content": reply})
    return jsonify({"reply": reply})

@app.post("/webhook")
def webhook():
    # LINE signature verification
    channel_secret = os.environ.get("LINE_CHANNEL_SECRET")
    if not channel_secret:
        abort(500, "LINE_CHANNEL_SECRET is not set")
    body = request.get_data(as_text=True)
    signature = request.headers.get("X-Line-Signature", "")

    digest = hmac.new(channel_secret.encode("utf-8"), body.encode("utf-8"), hashlib.sha256).digest()
    expected_sig = base64.b64encode(digest).decode()

    if not hmac.compare_digest(signature, expected_sig):
        abort(403, "invalid signature")

    payload = json.loads(body)
    events = payload.get("events", [])
    for ev in events:
        if ev.get("type") == "message" and ev.get("message", {}).get("type") == "text":
            user_text = ev["message"]["text"].strip()

            # Commands first
            cmd_resp = handle_command(user_text)
            if cmd_resp:
                send_line_reply(ev["replyToken"], cmd_resp)
                append_jsonl(CONV_FILE, {"role": "user", "content": user_text})
                append_jsonl(CONV_FILE, {"role": "assistant", "content": cmd_resp})
                continue

            msgs = [tina_system_prompt(), {"role": "system", "content": build_memory_hint()}, {"role": "user", "content": user_text}]
            try:
                reply = openai_chat(msgs)
            except Exception as e:
                reply = f"エラーが出たみたい：{e}"

            append_jsonl(CONV_FILE, {"role": "user", "content": user_text})
            append_jsonl(CONV_FILE, {"role": "assistant", "content": reply})
            send_line_reply(ev["replyToken"], reply)

    return "OK"

def send_line_reply(reply_token: str, text: str):
    access_token = os.environ.get("LINE_CHANNEL_ACCESS_TOKEN")
    if not access_token:
        return
    url = "https://api.line.me/v2/bot/message/reply"
    headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
    payload = {"replyToken": reply_token, "messages": [{"type": "text", "text": text[:4900]}]}
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=30)
        r.raise_for_status()
    except Exception:
        pass

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    app.run(host="0.0.0.0", port=port)
