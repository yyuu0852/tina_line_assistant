# ティナ（Tina）LINE 連携 AIサーバー - かんたんセットアップ

この手順通りに**iPad だけ**で進めれば、LINE で「ティナ」と話せます。  
（Render 無料枠を使用）

---

## 0. 用意するもの（無料）
- GitHub アカウント（Renderログイン用）
- Render アカウント（無料）
- LINE Developers アカウント（無料）
- OpenAI APIキー（https://platform.openai.com/api-keys）

> ※APIキーは Render の「Environment」へ貼り付けるだけ。ZIP には含めません。

---

## 1. Render にデプロイ
1) iPad の Safari で https://render.com → **Sign in with GitHub**  
2) 右上の **New +** → **Web Service**
3) リポジトリを選ぶ方式が基本です。**GitHub にこのフォルダを丸ごとアップロード**してから、Render でそのリポジトリを選択してください。
4) 設定例：
   - **Name**: `tina-line-assistant`
   - **Region**: Singapore（アジアに近い）
   - **Branch**: main（GitHub 側のブランチ）
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn app:app --bind 0.0.0.0:$PORT`
   - **Instance Type**: Free

5) 作成後、**Environment** に次を追加（Add Environment Variable）:
   - `OPENAI_API_KEY` = あなたの OpenAI API キー
   - `LINE_CHANNEL_SECRET` = LINE Developersのチャンネルシークレット
   - `LINE_CHANNEL_ACCESS_TOKEN` = チャンネルアクセストークン（長期）
   - （任意）`TZ` = `Asia/Tokyo`

6) デプロイが終わると URL が表示されます（例：`https://tina-line-assistant.onrender.com`）  
   → テスト用に `GET /` へアクセスすると「Tina is running.」と表示されます。

---

## 2. LINE Developers 設定（Messaging API）
1) https://developers.line.biz/ja/ → **コンソール** → **プロバイダー作成** → **チャネル作成（Messaging API）**
2) 作成後、**チャネル基本設定** で
   - **チャネルシークレット** … Render の `LINE_CHANNEL_SECRET` にコピペ
   - **アクセストークン（長期）** … Render の `LINE_CHANNEL_ACCESS_TOKEN` にコピペ
3) **Messaging API 設定** → **Webhook送信** を **有効**
4) **Webhook URL** に Render の URL を設定：  
   `https://<あなたの Render ドメイン>/webhook`
5) 「接続確認」ボタンで 200 OK になれば完了
6) **QRコード** から Bot を友だち追加 → LINE で話しかける

---

## 3. 使い方
- 普通に話しかけると、フレンドリーな「ティナ」が返事をします。
- コマンド例：
  - `/todo 追加 牛乳を買う`
  - `/todo 一覧`
  - `/todo 完了 1`
  - `/覚えて 好きな飲み物は烏龍茶`
  - `/思い出して`

> 会話やメモは `data/` フォルダに保存されます（Freeプランでは再デプロイ時に消えるため、重要データはバックアップ推奨）。

---

## 4. よくあるエラー
- 403 invalid signature → LINE_CHANNEL_SECRET が間違っている
- 401 Unauthorized → LINE_CHANNEL_ACCESS_TOKEN が間違っている or 権限不足
- 500 Internal Server Error → OPENAI_API_KEY 未設定 / 残高不足 / モデル名誤り

---

## 5. セキュリティ
- APIキーは**必ず** Render の Environment に保存（リポジトリに書かない）
- Webhook は HTTPS のみ（Render は自動で HTTPS）
- 公開Bot化する場合は、プライバシーポリシーのページを用意してください（個人利用なら不要）。
